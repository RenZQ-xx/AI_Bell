2024.5.30

randsphere is Skip Jordan's C code to produce random rational points on the 3-sphere

2024.2.8

These perl scripts were extracted from David Bremner's PolyBase page:

https://www.cs.unb.ca/~bremner/research/PolytopeBase/catalog/catmain.html

converted to be standalone perl scripts.

Corrections:

Metric(n)

n_facets   2n(n-1)(n-2)/3

